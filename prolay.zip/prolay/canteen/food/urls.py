from django.conf.urls import url
from .views import item_list

app_name = 'food'


urlpatterns = [
    url(r'^$', item_list, name='item_list'),
    
]