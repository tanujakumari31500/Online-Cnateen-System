from django.shortcuts import render
from .models import item

# Create your views here.

def item_list(request):
    context = {
        'items' : item.objects.all()
    }
    return render(request, "item_list.html",context)